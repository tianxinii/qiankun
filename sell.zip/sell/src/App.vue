<template>
    <div>   
        <v-header></v-header>
        <div class="tab">
            <div class="tab-item">
                <a><router-link to="/goods">商品</router-link></a>
            </div>
            <div class="tab-item">
                <a><router-link to="/ratings">评论</router-link></a>
            </div>
            <div class="tab-item">
               <a><router-link to="/seller">商家</router-link></a>
            </div>
        </div>
         <router-view></router-view>
    </div>
</template>

<script type="text/ecmascript-6">
var config = require('../config/index');
  import header from 'components/header/header'
  export default {
    data(){
        return{
            seller:{}
        }
    },
    created() {
        this.$http.get('/api/seller').then((response)=>{
            console.log(resppnse)
            response=response.body
            if(response.errno===0){
                this.seller=response.data
            }
        })
    },
    components:{  
      'v-header':header
    }
  }
</script>

<style lang="stylus" rel="stylesheet/stylus">
@import "./common/stylus/mixin.styl"
 .tab
    display:flex
    width:100%
    height :40px
    line-height :40px
    border-bottom:1px solid  rgba(7,17,27,0.1)
    // border-1px(rgba(7,17,27,0.1))
    .tab-item
        flex:1
        text-align:center
        a
            display: block
            font-size: 14px
            color: rgb(77, 85, 93)
            text-decoration:none
            &.active
                color: rgb(240, 20, 20)
</style>
