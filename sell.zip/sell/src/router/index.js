import Vue from 'vue'
import Router from 'vue-router'
import header from 'components/header/header'

import goods from 'components/goods/goods'
import ratings from 'components/ratings/ratings'
import seller from 'components/seller/seller'

import VueResource from 'vue-resource';
Vue.use(VueResource)


Vue.use(Router)
export default new Router({
    base: window.__POWERED_BY_QIANKUN__ ? 'sell' : '/',
    mode: 'history',
    linkActiveClass: 'active',
    routes:[
        {path:'/goods',component: goods},
        {path:'/ratings',component: ratings},
        {path:'/seller',component: seller},
        
  ]
})
